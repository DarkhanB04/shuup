Basic Administration Tasks
==========================

.. TODO:: Revise this when user management lands in the admin.

You can use the built-in Django management commands
:djadmin:`createsuperuser` and :djadmin:`changepassword` to manage
superusers and change user passwords.

See also :ref:`topics-auth-creating-superusers` from Django's
documentation.
