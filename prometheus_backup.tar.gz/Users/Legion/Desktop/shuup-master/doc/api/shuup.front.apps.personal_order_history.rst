shuup\.front\.apps\.personal\_order\_history package
====================================================

Submodules
----------

shuup\.front\.apps\.personal\_order\_history\.dashboard\_items module
---------------------------------------------------------------------

.. automodule:: shuup.front.apps.personal_order_history.dashboard_items
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.front\.apps\.personal\_order\_history\.urls module
---------------------------------------------------------

.. automodule:: shuup.front.apps.personal_order_history.urls
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.front\.apps\.personal\_order\_history\.views module
----------------------------------------------------------

.. automodule:: shuup.front.apps.personal_order_history.views
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.front.apps.personal_order_history
    :members:
    :undoc-members:
    :show-inheritance:
