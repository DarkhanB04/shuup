shuup\.xtheme\.admin\_module\.views package
===========================================

Module contents
---------------

.. automodule:: shuup.xtheme.admin_module.views
    :members:
    :undoc-members:
    :show-inheritance:
