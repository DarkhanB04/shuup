shuup\.core\.suppliers package
==============================

Submodules
----------

shuup\.core\.suppliers\.base module
-----------------------------------

.. automodule:: shuup.core.suppliers.base
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.core\.suppliers\.enums module
------------------------------------

.. automodule:: shuup.core.suppliers.enums
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.core\.suppliers\.strategies module
-----------------------------------------

.. automodule:: shuup.core.suppliers.strategies
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.core.suppliers
    :members:
    :undoc-members:
    :show-inheritance:
