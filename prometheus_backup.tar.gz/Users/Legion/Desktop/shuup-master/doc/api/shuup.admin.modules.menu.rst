shuup\.admin\.modules\.menu package
===================================

Subpackages
-----------

.. toctree::

    shuup.admin.modules.menu.views

Module contents
---------------

.. automodule:: shuup.admin.modules.menu
    :members:
    :undoc-members:
    :show-inheritance:
