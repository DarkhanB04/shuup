shuup\.core\.taxing package
===========================

Submodules
----------

shuup\.core\.taxing\.utils module
---------------------------------

.. automodule:: shuup.core.taxing.utils
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.core.taxing
    :members:
    :undoc-members:
    :show-inheritance:
